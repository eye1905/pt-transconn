<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login_model extends CI_Model
{
	public function getJabatan()
	{
		$query = " SELECT jabatan.*, pegawai.nama_pegawai
                    FROM jabatan JOIN pegawai
                    ON jabatan.id_jabatan = pegawai.id_jabatan
                    ";
		return $this->db->query($query);
	}

	public function setFcm($username, $fcm = '')
	{
		$updatefcm = "UPDATE pegawai SET fcm_id = '$fcm' WHERE nomor_hp = " . $username;
		return $this->db->query($updatefcm);
	}
}
