<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Suratmasuk extends REST_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Surat_model', 'surat');
	}

	public function list_post()
	{
		$username  = $this->post('nomor_hp');
		$status    = $this->post('status');
		$role = $this->input->post('role');

		if ($username !== '' && $status !== '') {
			$querry = $this->db
				->select('*')
				->from('pegawai')
				->where('nomor_hp = ', $username)
				->get()->num_rows();

			if ($querry > 0 && $status === '1') {
				$limit = $this->post('limit');
				$suratlist = $this->surat->get_surat_listapinonpending();

				if ($limit !== '') {
					$suratlist = $this->surat->get_surat_listapinonpending($limit)->result_array();
				}

				if ($role == '4' && $limit != '') {
					$suratlist = $this->surat->get_surat_listapifull($limit)->result_array();
				}

				if ($suratlist) {
					$this->response([
						'Respon_code' => '00',
						'Respon_message' => 'success',
						'Respon_date' => date('d-M-Y h:i'),
						'Respon_data' => $suratlist
					], REST_Controller::HTTP_OK);
				} else {
					$this->response([
						'Respon_code' => '01',
						'Respon_message' => 'Data surat masuk tidak ditemukan.',
						'Respon_date' => date('d-M-Y h:i'),
					], REST_Controller::HTTP_NOT_FOUND);
				}
			}
		} else {
			$this->response([
				'Respon_status' => '02',
				'Respon_message' => 'Parameter Valid dibutuhkan.',
				'Respon_date' => date('d-M-Y h:i'),
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function search_post()
	{
		$username  = $this->post('nomor_hp');
		$status    = $this->post('status');

		// parameter
		$nosurat = $this->post('nosurat');
		$noagenda = $this->post('noagenda');
		$tglsurat = $this->post('tglsurat');
		$tglditerima = $this->post('tglditerima');
		$sifatsurat = $this->post('sifatsurat');

		if ($username != '' && $status !== '') {

			if ($nosurat != '' || $noagenda != '' || $tglsurat != '' || $tglditerima != '' || $sifatsurat != '') {
				$querry = $this->db
					->select('*')
					->from('pegawai')
					->where('nomor_hp = ', $username)
					->get()->num_rows();

				if ($querry > 0 && $status === '1') {
					$suratlistbysearch = $this->surat->get_surat_listfilter($nosurat, $noagenda, $tglsurat, $tglditerima, $sifatsurat)->result_array();
					if ($suratlistbysearch) {
						$this->response([
							'Respon_code' => '00',
							'Respon_message' => 'success',
							'Respon_date' => date('d-M-Y h:i'),
							'Respon_data' => $suratlistbysearch
						], REST_Controller::HTTP_OK);
					} else {
						$this->response([
							'Respon_code' => '01',
							'Respon_message' => 'Data surat masuk tidak ditemukan.',
							'Respon_date' => date('d-M-Y h:i'),
						], REST_Controller::HTTP_NOT_FOUND);
					}
				}
			} else {
				$this->response([
					'Respon_code' => '00',
					'Respon_message' => 'Kata kunci diperlukan.',
					'Respon_date' => date('d-M-Y h:i'),
				], REST_Controller::HTTP_OK);
			}
		} else {
			$this->response([
				'Respon_code' => '02',
				'Respon_message' => 'Parameter Valid dibutuhkan.',
				'Respon_date' => date('d-M-Y h:i'),
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function updatestatus_post()
	{
		// parameter
		$username  = $this->post('nomor_hp');
		$status    = $this->post('status');

		// status sm
		$idsm = $this->post('idsm');
		$status3 = $this->post('statusitem');

		// logic user
		$querry = $this->db
			->select('*')
			->from('pegawai')
			->where('nomor_hp = ', $username)
			->get()->result_array();


		if ($idsm != '' && $status3 != '' && $username != '' && $status !== '' && $querry != null && $status === '1' && $querry[0]['id_role'] == '2') {

			$insertstatus = $this->surat->updatestts($idsm, $status3);

			if ($insertstatus == true) {
				$this->response([
					'Respon_code' => '00',
					'Respon_message' => 'success',
					'Respon_date' => date('d-M-Y h:i')
				], REST_Controller::HTTP_OK);
			} else {
				$this->response([
					'Respon_code' => '02',
					'Respon_message' => 'Parameter Valid dibutuhkan.',
					'Respon_date' => date('d-M-Y h:i'),
				], REST_Controller::HTTP_BAD_REQUEST);
			}
		} else {
			$this->response([
				'Respon_code' => '02',
				'Respon_message' => 'Parameter Valid dibutuhkan.',
				'Respon_date' => date('d-M-Y h:i'),
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function index_get()
	{
		$this->response([
			'Respon_status' => '00',
			'Respon_message' => 'Cie pakai get :)',
		], REST_Controller::HTTP_FORBIDDEN);
	}
}
