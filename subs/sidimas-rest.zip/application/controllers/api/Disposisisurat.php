<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Disposisisurat extends REST_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Disposisi_model', 'Disposisi');
		$this->load->model('Surat_model', 'sm');
		$this->load->model('Notif_model');
	}


	public function list_post()
	{
		$username  = $this->post('nomor_hp');
		$status    = $this->post('status');

		if ($username !== '' && $status !== '') {
			$querry = $this->db
				->select('*')
				->from('pegawai')
				->where('nomor_hp = ', $username)
				->get()->num_rows();

			if ($querry > 0 && $status === '1') {
				$limit = $this->post('limit');
				$dpsslist = $this->Disposisi->get_dpss_listAPI()->result_array();

				if ($limit !== '') {
					$dpsslist = $this->Disposisi->get_dpss_listAPI($limit)->result_array();
				}

				if ($dpsslist) {
					$this->response([
						'Respon_code' => '00',
						'Respon_message' => 'success',
						'Respon_date' => date('d-M-Y h:i'),
						'Respon_data' => $dpsslist
					], REST_Controller::HTTP_OK);
				} else {
					$this->response([
						'Respon_code' => '01',
						'Respon_message' => 'Data disposisi tidak ditemukan.',
						'Respon_date' => date('d-M-Y h:i'),
					], REST_Controller::HTTP_NOT_FOUND);
				}
			}
		} else {
			$this->response([
				'Respon_status' => '02',
				'Respon_message' => 'Parameter dibutuhkan',
				'Respon_date' => date('d-M-Y h:i'),
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}


	public function byid_post()
	{
		$username  = $this->post('nomor_hp');
		$status    = $this->post('status');
		$id_dpss = $this->post('key');
		if ($id_dpss != '' && $username != '' && $status !== '') {

			$querry = $this->db
				->select('*')
				->from('pegawai')
				->where('nomor_hp = ', $username)
				->get()->num_rows();

			if ($querry > 0 && $status === '1') {
				$dpsslistbyid = $this->Disposisi->getById($id_dpss)->result_array();
				$perintahdpss = $this->Disposisi->getperintahById($id_dpss)->result_array();
				if ($dpsslistbyid) {
					$this->response([
						'Respon_code' => '00',
						'Respon_message' => 'success',
						'Respon_date' => date('d-M-Y h:i'),
						'Respon_dpss' => $dpsslistbyid,
						'Respon_perintah' => $perintahdpss
					], REST_Controller::HTTP_OK);
				} else {
					$this->response([
						'Respon_code' => '01',
						'Respon_message' => 'Data tidak ditemukan.',
						'Respon_date' => date('d-M-Y h:i'),
					], REST_Controller::HTTP_NOT_FOUND);
				}
			}
		} else {
			$this->response([
				'Respon_code' => '02',
				'Respon_message' => 'Parameter dibutuhkan.',
				'Respon_date' => date('d-M-Y h:i'),
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function byidpeg_post()
	{
		$username  = $this->post('nomor_hp');
		$status    = $this->post('status');
		$id_pegawai = $this->post('peg');

		if ($id_pegawai != '' && $username != '' && $status !== '') {
			$querry = $this->db
				->select('*')
				->from('pegawai')
				->where('id_pegawai = ', (int)$id_pegawai)
				->where('nomor_hp = ', $username)
				->get()->num_rows();

			if ($querry > 0 && $status === '1') {
				$dpsslistbyidpeg = $this->Disposisi->getdppsbyidpeg($id_pegawai)->result_array();
				if ($dpsslistbyidpeg) {
					$this->response([
						'Respon_code' => '00',
						'Respon_message' => 'success',
						'Respon_date' => date('d-M-Y h:i'),
						'Respon_data' => $dpsslistbyidpeg
					], REST_Controller::HTTP_OK);
				} else {
					$this->response([
						'Respon_code' => '01',
						'Respon_message' => 'Data disposisi tidak ditemukan.',
						'Respon_date' => date('d-M-Y h:i'),
						'Respon_data' => null
					], REST_Controller::HTTP_NOT_FOUND);
				}
			}
		} else {
			$this->response([
				'Respon_code' => '02',
				'Respon_message' => 'Parameter dibutuhkan.',
				'Respon_date' => date('d-M-Y h:i'),
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function tujuandisposisi_post()
	{
		$username  = $this->post('nomor_hp');
		$status    = $this->post('status');
		if ($username != '' && $status !== '') {

			$querry = $this->db
				->select('*')
				->from('pegawai')
				->where('nomor_hp = ', $username)
				->get()->num_rows();

			if ($querry > 0 && $status === '1') {
				$jabatan = $this->Disposisi->getjabatan()->result_array();
				$pegawailainnya = $this->Disposisi->getpegawaibiasa()->result_array();
				$perintah = $this->Disposisi->getperintah()->result_array();

				if ($jabatan > 0 && $pegawailainnya > 0 && $perintah > 0) {
					$this->response([
						'Respon_code' => '00',
						'Respon_message' => 'success',
						'Respon_date' => date('d-M-Y h:i'),
						'Respon_jabatan' => $jabatan,
						'Respon_pegawai' => $pegawailainnya,
						'Respon_perintah' => $perintah
					], REST_Controller::HTTP_OK);
				} else {
					$this->response([
						'Respon_code' => '01',
						'Respon_message' => '.',
						'Respon_date' => date('d-M-Y h:i'),
					], REST_Controller::HTTP_NOT_FOUND);
				}
			}
		} else {
			$this->response([
				'Respon_code' => '02',
				'Respon_message' => 'Parameter dibutuhkan.',
				'Respon_date' => date('d-M-Y h:i'),
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}


	// CRUD
	public function add_post()
	{
		// parameter
		$username  = $this->post('nomor_hp');
		$status    = $this->post('status');

		// disposisi
		$id_surat = $this->post('id_surat');
		$derajat_surat = $this->post('derajatsm');
		$waktu_penyelesaian = $this->post('batas_waktu');
		$nomor_agenda = $this->post('nomor_agenda');
		$catatan = $this->post('catatan');

		//tujuan
		$jabatan = $this->post('jabatan');
		$pegawai = $this->post('pegawai');
		$perintah = $this->post('perintahid');


		// logic user
		$querry = $this->db
			->select('*')
			->from('pegawai')
			->where('nomor_hp = ', $username)
			->get()->result_array();


		if ($id_surat != '' && $derajat_surat != '' && $waktu_penyelesaian != '' && $nomor_agenda != '' && $catatan != '' && $jabatan != '[]' && $perintah != '[]' && $username != '' && $status !== '' && $querry != null && $status === '1' && $querry[0]['id_role'] == '2') {

			if ($this->Disposisi->save_dpss($id_surat, $derajat_surat, $waktu_penyelesaian, $nomor_agenda, $catatan) == true) {
				$iddpsslast = $this->db->insert_id();
				$this->sm->updatesttstodpss($id_surat);
				if ($jabatan != null && $jabatan != '[]') {
					$this->Disposisi->save_ditujukanjabatan($iddpsslast, $jabatan);
				}
				if ($perintah != null && $perintah != '[]') {
					$this->Disposisi->save_perintah($iddpsslast, $perintah);
				}
				if ($pegawai != null && $pegawai != '[]') {
					$this->Disposisi->save_pegawaistaff($iddpsslast, $pegawai);
				}
				$this->response([
					'Respon_code' => '00',
					'Respon_message' => 'success',
					'Respon_date' => date('d-M-Y h:i')
				], REST_Controller::HTTP_OK);
			} else {
				$this->response([
					'Respon_code' => '02',
					'Respon_message' => 'Pastikan semua paramter valid.',
					'Respon_date' => date('d-M-Y h:i'),
				], REST_Controller::HTTP_BAD_REQUEST);
			}
		} else {
			$this->response([
				'Respon_code' => '02',
				'Respon_message' => 'Parameter valid dibutuhkan.',
				'Respon_date' => date('d-M-Y h:i'),
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function dpsstatus_post()
	{
		// parameter
		$username  = $this->post('nomor_hp');
		$status    = $this->post('status');

		// id
		$id_dpss = $this->post('iddpss');
		$pegawai = $this->post('pegawai');

		// logic user
		$querry = $this->db
			->select('*')
			->from('pegawai')
			->where('nomor_hp = ', $username)
			->get()->result_array();

		$detstatus = $this->db
			->select('id_stats')
			->from('det_dpss')
			->where("id_disposisi = '$id_dpss' AND id_pegawai = '$pegawai'")
			->get()->result_array();

		if ($id_dpss != ''  && $pegawai != '' && $querry != null && $status === '1') {
			if ($detstatus[0]['id_stats'] == '1' && $this->Disposisi->updatesttsdpss($id_dpss, $pegawai) == true && $this->Disposisi->waktubacainput($id_dpss, $pegawai) == true) {
				$this->response([
					'Respon_code' => '00',
					'Respon_message' => 'success',
					'Respon_date' => date('d-M-Y h:i')
				], REST_Controller::HTTP_OK);
			} else {
				$this->response([
					'Respon_code' => '00',
					'Respon_message' => 'Status telah diubah sebelumnya.',
					'Respon_date' => date('d-M-Y h:i'),
				], REST_Controller::HTTP_OK);
			}
		} else {
			$this->response([
				'Respon_code' => '02',
				'Respon_message' => 'Parameter valid dibutuhkan.',
				'Respon_date' => date('d-M-Y h:i'),
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function notifdpss_get()
	{
		$batasan_waktu = 5; // menit;

		$time_start = microtime(true);

		$nomor = $this->Notif_model->getout();

		if ($nomor != null) {
			foreach ($nomor as $nmr) {

				if ($this->Notif_model->notification_android($nmr['body'], $nmr['title'], $nmr['route'], $nmr['id_data'], $nmr['fcm_id'])) {
					$this->Notif_model->updatesttssending($nmr['id_notif']);
					echo '<pre>';
					echo 'SUCCESS';
				} else {
					echo '<pre>';
					echo 'GAGAL';
				}
				$current_time = microtime(true);
				$interval = $current_time - $time_start;

				if ($interval >= $batasan_waktu) {
					break;
				}
			}
		}
	}

	public function index_get()
	{
		$this->response([
			'Respon_status' => '00',
			'Respon_message' => 'Cie pakai get :)',
		], REST_Controller::HTTP_FORBIDDEN);
	}
}
