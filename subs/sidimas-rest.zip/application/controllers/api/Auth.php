<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Auth extends REST_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('Login_model', 'login');
	}


	public function index_post()
	{

		// REQUIRED INPUT
		$username  = $this->post('nomor_hp');
		$password  = $this->post('sandi');
		$fcm = $this->post('fcmid');


		if ($username !== '' && $password !== '') {

			$userdetail = $this->db
				->select('pg.*, jb.id_jabatan, jb.nama_jabatan, jb.position')
				->from('pegawai pg')
				->join('jabatan jb', 'jb.id_jabatan = pg.id_jabatan')
				->where('nomor_hp = ', $username)
				->get()->row_array();

			$fcmset = $this->login->setFcm($username, $fcm);

			if ($userdetail > 0) {
				if (password_verify($password, $userdetail['password'])) {
					$fcmset;
					$this->response([
						'Respon_code' => '00',
						'Respon_message' => 'success',
						'Respon_date' => date('d-M-Y h:i'),
						'Respon_data' => $userdetail
					], REST_Controller::HTTP_OK);
				} else {
					$this->response([
						'Respon_code' => '01',
						'Respon_message' => 'Nomor Hp atau Password Salah.',
						'Respon_date' => date('d-M-Y h:i'),
						'Respon_data' => []
					], REST_Controller::HTTP_NOT_FOUND);
				}
			} else {
				$this->response([
					'Respon_code' => '01',
					'Respon_message' => 'User tidak ditemukan.',
					'Respon_date' => date('d-M-Y h:i'),
					'Respon_data' => []
				], REST_Controller::HTTP_NOT_FOUND);
			}
		} else {
			$this->response([
				'Respon_status' => '02',
				'Respon_message' => 'Parameter dibutuhkan',
				'Respon_date' => date('d-M-Y h:i'),
				'Respon_data' => []
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}


	public function index_get()
	{
		$this->response([
			'Respon_status' => '00',
			'Respon_message' => 'Cie pakai get :)',
		], REST_Controller::HTTP_FORBIDDEN);
	}
}
